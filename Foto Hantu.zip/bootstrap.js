// FotoHantu -- bootstrap.js
var app = this;
